const weatherData = {
  tempUnit: 'C',
  windSpeedUnit: 'm/s',
  days: [{
      day: 'Monday',
      temp: 22,
      windDirection: 'north-east',
      windDirectionImage: 'sprite-north-east',
      windSpeed: 10,
      type: 'sunny',
      path: 'spritefc-sun'
    },
    {
      day: 'Tuesday',
      temp: 14,
      windDirection: 'north-west',
      windDirectionImage: 'sprite-north-west',
      windSpeed: 14,
      type: 'rainy',
      path: 'spritefc-raining'
    },
    {
      day: 'Wednesday',
      temp: 17,
      windDirection: 'south-east',
      windDirectionImage: 'sprite-south-east',
      windSpeed: 20,
      type: 'cloudy',
      path: 'spritefc-cloud'
    },
    {
      day: 'Thursday',
      temp: 7,
      windDirection: 'south-west',
      windDirectionImage: 'sprite-south-west',
      windSpeed: 11,
      type: 'foggy',
      path: 'spritefc-mist'
    },
    {
      day: 'Friday',
      temp: 28,
      windDirection: 'north-west',
      windDirectionImage: 'sprite-north-west',
      windSpeed: 5,
      type: 'sunny',
      path: 'spritefc-sun'
    },
    {
      day: 'Saturday',
      temp: 12,
      windDirection: 'south-east',
      windDirectionImage: 'sprite-south-east',
      windSpeed: 18,
      type: 'windy',
      path: 'spritefc-windy'
    },
    {
      day: 'Sunday',
      temp: -3,
      windDirection: 'south-west',
      windDirectionImage: 'sprite-south-west',
      windSpeed: 9,
      type: 'snowy',
      path: 'spritefc-snowy'
    }
  ]
};

let days = document.getElementsByClassName("day"),
    close = document.getElementsByClassName("close"),
    temperature = document.getElementsByClassName("temperature"),
    windSpeed = document.getElementsByClassName("wind-speed"),
    img = document.getElementsByClassName("spritefc"),
    arrows = document.getElementsByClassName("sprite");

function pass() {
  let daynames = document.getElementsByClassName("day-name");
      daytypes = document.getElementsByClassName("day-type"),
      direction = document.getElementsByClassName("direction");
  for (let i = 0; i < days.length; i++) {
    daynames[i].innerHTML = weatherData.days[i].day;
    daytypes[i].innerHTML = `The day will be ${weatherData.days[i].type}`;
    temperature[i].innerHTML = `Temperature: ${weatherData.days[i].temp}&deg;C`;
    direction[i].innerHTML = `Wind direction: ${weatherData.days[i].windDirection}`;
    arrows[i].classList.add(weatherData.days[i].windDirectionImage);
    windSpeed[i].innerHTML = `Wind speed: ${weatherData.days[i].windSpeed}m/s`;
    img[i].classList.add(weatherData.days[i].path);
  }
}

pass();

function kelv() {
  for (let i = 0; i < temperature.length; i++) {
    temperature[i].innerHTML = `Temperature: ${weatherData.days[i].temp + 273} K`;
  }
}

function celsius() {
  for (let i = 0; i < temperature.length; i++) {
    temperature[i].innerHTML = `Temperature: ${weatherData.days[i].temp}&deg;C`;
  }
}

function km() {
  for (let i = 0; i < windSpeed.length; i++) {
    windSpeed[i].innerHTML = `Wind speed: ${Math.round(weatherData.days[i].windSpeed / 3.6 * 100) / 100} km/h`;
  }
}

function ms() {
  for (let i = 0; i < windSpeed.length; i++) {
    windSpeed[i].innerHTML = `Wind speed: ${weatherData.days[i].windSpeed} m/s`;
  }
}

// EVENT LISTENERS

let monday = document.getElementById("monday"),
  tuesday = document.getElementById("tuesday"),
  wednesday = document.getElementById("wednesday"),
  thursday = document.getElementById("thursday"),
  friday = document.getElementById("friday"),
  saturday = document.getElementById("saturday"),
  sunday = document.getElementById("sunday");

let bigName = document.getElementsByClassName("big-day-name"),
    bigType = document.getElementsByClassName("big-day-type"),
    bigTemp = document.getElementsByClassName("big-temperature"),
    bigWind = document.getElementsByClassName("big-wind-speed"),
    bigDir = document.getElementsByClassName("big-direction");

monday.addEventListener("click", () => {
  document.getElementById("monday-big").style.display = 'block';
  bigName[0].innerHTML = weatherData.days[0].day;
  bigType[0].innerHTML = `The day will be ${weatherData.days[0].type}`;
  bigTemp[0].innerHTML = `Temperature: ${weatherData.days[0].temp}&deg;C`;
  bigWind[0].innerHTML = `Wind speed: ${weatherData.days[0].windSpeed}`;
  bigDir[0].innerHTML = `Wind direction: ${weatherData.days[0].windDirection}`;
  arrows[0].classList.add(weatherData.days[0].windDirectionImage);
  img[0].classList.add(weatherData.days[0].path);
});

document.getElementsByClassName("close")[0].addEventListener("click", () => {
  document.getElementById('monday-big').style.display = 'none';
});

tuesday.addEventListener("click", () => {
  document.getElementById("tuesday-big").style.display = 'block';
  bigName[1].innerHTML = weatherData.days[1].day;
  bigType[1].innerHTML = `The day will be ${weatherData.days[1].type}`;
  bigTemp[1].innerHTML = `Temperature: ${weatherData.days[0].temp}&deg;C`;
  bigWind[1].innerHTML = `Wind speed ${weatherData.days[0].windSpeed}`;
  bigDir[1].innerHTML = `Wind direction: ${weatherData.days[0].windDirection}`;
  document.getElementById("dir-tue").classList.add(weatherData.days[1].windDirectionImage);
  document.getElementById("weath-tue").classList.add(weatherData.days[1].path);
});

document.getElementsByClassName("close")[1].addEventListener("click", () => {
  document.getElementById("tuesday-big").style.display = "none";
});

wednesday.addEventListener("click", () => {
  document.getElementById("wednesday-big").style.display = 'block';
  bigName[2].innerHTML = weatherData.days[2].day;
  bigType[2].innerHTML = `The day will be ${weatherData.days[2].type}`;
  bigTemp[2].innerHTML = `Temperature: ${weatherData.days[2].temp}&deg;C`;
  bigWind[2].innerHTML = `Wind speed ${weatherData.days[2].windSpeed}`;
  bigDir[2].innerHTML = `Wind direction: ${weatherData.days[2].windDirection}`;
  document.getElementById("dir-wed").classList.add(weatherData.days[2].windDirectionImage);
  document.getElementById("weath-wed").classList.add(weatherData.days[2].path);
});

document.getElementsByClassName("close")[2].addEventListener("click", () => {
  document.getElementById("wednesday-big").style.display = "none";
});

thursday.addEventListener("click", () => {
  document.getElementById("thursday-big").style.display = 'block';
  bigName[3].innerHTML = weatherData.days[3].day;
  bigType[3].innerHTML = `The day will be ${weatherData.days[3].type}`;
  bigTemp[3].innerHTML = `Temperature: ${weatherData.days[3].temp}`;
  bigWind[3].innerHTML = `Wind speed: ${weatherData.days[3].windSpeed}`;
  bigDir[3].innerHTML = `Wind direction ${weatherData.days[3].windDirection}`;
  document.getElementById("dir-thu").classList.add(weatherData.days[3].windDirectionImage);
  document.getElementById("weath-thu").classList.add(weatherData.days[3].path);
});

document.getElementsByClassName("close")[3].addEventListener("click", () => {
  document.getElementById("thursday-big").style.display = "none";
});

friday.addEventListener("click", () => {
  document.getElementById("friday-big").style.display = 'block';
  bigName[4].innerHTML = weatherData.days[4].day;
  bigType[4].innerHTML = `The day will be ${weatherData.days[4].type}`;
  bigTemp[4].innerHTML = `Temperature: ${weatherData.days[4].temp}`;
  bigWind[4].innerHTML = `Wind speed: ${weatherData.days[4].windSpeed}`;
  bigDir[4].innerHTML = `Wind direction ${weatherData.days[3].windDirection}`;
  document.getElementById("dir-fri").classList.add(weatherData.days[4].windDirectionImage);
  document.getElementById("weath-fri").classList.add(weatherData.days[4].path);
});

document.getElementsByClassName("close")[4].addEventListener("click", () => {
  document.getElementById("friday-big").style.display = "none";
});

saturday.addEventListener("click", () => {
  document.getElementById("saturday-big").style.display = 'block';
  bigName[5].innerHTML = weatherData.days[5].day;
  bigType[5].innerHTML = `The day will be ${weatherData.days[5].type}`;
  bigTemp[5].innerHTML = `Temperature: ${weatherData.days[5].temp}`;
  bigWind[5].innerHTML = `Wind speed: ${weatherData.days[5].windSpeed}`;
  bigDir[5].innerHTML = `Wind direction ${weatherData.days[5].windDirection}`;
  document.getElementById("dir-sat").classList.add(weatherData.days[5].windDirectionImage);
  document.getElementById("weath-sat").classList.add(weatherData.days[5].path);
});

document.getElementsByClassName("close")[5].addEventListener("click", () => {
  document.getElementById("saturday-big").style.display = "none";
});

sunday.addEventListener("click", () => {
  document.getElementById("sunday-big").style.display = 'block';
  bigName[6].innerHTML = weatherData.days[6].day;
  bigType[6].innerHTML = `The day will be ${weatherData.days[6].type}`;
  bigTemp[6].innerHTML = `Temperature: ${weatherData.days[6].temp}`;
  bigWind[6].innerHTML = `Wind speed: ${weatherData.days[6].windSpeed}`;
  bigDir[6].innerHTML = `Wind direction ${weatherData.days[6].windDirection}`;
  document.getElementById("dir-sun").classList.add(weatherData.days[6].windDirectionImage);
  document.getElementById("weath-sun").classList.add(weatherData.days[6].path);
});

document.getElementsByClassName("close")[6].addEventListener("click", () => {
  document.getElementById("sunday-big").style.display = "none";
});
