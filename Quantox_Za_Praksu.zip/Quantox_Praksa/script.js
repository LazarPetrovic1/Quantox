const weatherData = {
  tempUnit: 'C',
  windSpeedUnit: 'm/s',
  days: [
    {day: 'Monday', temp: 22, windDirection: 'north-east', windDirectionImage: 'sprite-north-east', windSpeed: 10, type: 'sunny', path: 'spritefc-sun'},
    {day: 'Tuesday', temp: 14, windDirection: 'north-west', windDirectionImage: 'sprite-north-west', windSpeed: 14, type: 'rainy', path: 'spritefc-raining'},
    {day: 'Wednesday', temp: 17, windDirection: 'south-east', windDirectionImage: 'sprite-south-east', windSpeed: 20, type: 'cloudy', path: 'spritefc-cloud'},
    {day: 'Thursday', temp: 7, windDirection: 'south-west', windDirectionImage: 'sprite-south-west', windSpeed: 11, type: 'foggy', path: 'spritefc-mist'},
    {day: 'Friday', temp: 28, windDirection: 'north-west', windDirectionImage: 'sprite-north-west', windSpeed: 5, type: 'sunny', path: 'spritefc-sun'},
    {day: 'Saturday', temp: 12, windDirection: 'south-east', windDirectionImage: 'sprite-south-east', windSpeed: 18, type: 'windy', path: 'spritefc-windy'},
    {day: 'Sunday', temp: -3, windDirection: 'south-west', windDirectionImage: 'sprite-south-west', windSpeed: 9, type: 'snowy', path: 'spritefc-snowy'}
  ]
};

let days = document.getElementsByClassName("day");
let bigDay = document.getElementsByClassName("big-day");
let close = document.getElementsByClassName("close");
let main = document.getElementById("main");
let temperature = document.getElementsByClassName("temperature");
let windSpeed = document.getElementsByClassName("wind-speed");

function pass() {
  let daynames =  document.getElementsByClassName("day-name");
  let daytypes = document.getElementsByClassName("day-type");
  let direction = document.getElementsByClassName("direction");
  let img = document.getElementsByClassName("spritefc");
  let arrows = document.getElementsByClassName("sprite");
  for (let i = 0; i < days.length; i++) {
    daynames[i].innerHTML = weatherData.days[i].day;
    daytypes[i].innerHTML = `The day will be ${weatherData.days[i].type}`;
    temperature[i].innerHTML = `Temperature: ${weatherData.days[i].temp}&deg;C`;
    windSpeed[i].innerHTML = `Wind speed: ${weatherData.days[i].windSpeed}m/s`;
    direction[i].innerHTML = `Wind direction: ${weatherData.days[i].windDirection}`;
    img[i].classList.add(weatherData.days[i].path);
    arrows[i].classList.add(weatherData.days[i].windDirectionImage);
  }
}

pass();

for (let i = 0; i < days.length; i++) {
  days[i].addEventListener("click", () => {
    days[i].classList.toggle("big-day");
    document.body.classList.toggle("screen-black");
    close[i].style.display = 'block';
  });
}

main.addEventListener("click", () => {
  void(0);
});

function kelv() {
  for (let i = 0; i < temperature.length; i++) {
  temperature[i].innerHTML = `Temperature: ${weatherData.days[i].temp + 273} K`;
  }
}

function celsius() {
  for (let i = 0; i < temperature.length; i++) {
  temperature[i].innerHTML = `Temperature: ${weatherData.days[i].temp}&deg;C`;
  }
}

function km() {
  for (let i = 0; i < windSpeed.length; i++) {
    windSpeed[i].innerHTML = `Wind speed: ${Math.round(weatherData.days[i].windSpeed / 3.6 * 100) / 100} km/h`;
  }
}

function ms() {
  for (let i = 0; i < windSpeed.length; i++) {
    windSpeed[i].innerHTML = `Wind speed: ${weatherData.days[i].windSpeed} m/s`;
  }
}
